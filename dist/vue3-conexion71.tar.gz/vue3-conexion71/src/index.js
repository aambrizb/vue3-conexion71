import SelectFrame from "./SelectFrame.vue";

export { SelectFrame };
